#include <iostream>
#include <vector>

int main() {
    // Take width and height input from user
    size_t width = 3, height = 3;
    // std::cout << "Enter width: ";
    // std::cin >> width;
    // std::cout << "Enter height: ";
    // std::cin >> height;

    // Initialize the image vector with sequential values
    std::vector<int> image(width * height);
    for (size_t i = 0; i < width * height; ++i) {
        image[i] = i + 1; // Example initialization with sequential values
    }

    // Kernel remains the same
    const std::vector<int> kernel = {
        1, 0, -1,
        2, 0, -2,
        1, 0, -1
    };

    // Initialize the result vector
    std::vector<int> result(width * height, 0);

    // Perform the convolution operation
    for (size_t i = 0; i < height; ++i) {
        for (size_t j = 0; j < width; ++j) {
            int sum = 0;
            for (int kx = -1; kx <= 1; ++kx) {
                for (int ky = -1; ky <= 1; ++ky) {
                    int imageX = i + kx;
                    int imageY = j + ky;
                    if (imageX >= 0 && imageX < width && imageY >= 0 && imageY < height) {
                        sum += image[imageX * width + imageY] * kernel[(kx + 1) * 3 + (ky + 1)];
                    }
                }
            }
            result[i * width + j] = sum;
        }
    }

    // Output the result
    std::cout << "Convolution Result:" << std::endl;
    for (size_t i = 0; i < height; ++i) {
        for (size_t j = 0; j < width; ++j) {
            std::cout << result[i * width + j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}


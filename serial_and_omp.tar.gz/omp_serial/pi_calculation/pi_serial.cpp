#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip> // For setting the precision of the output

int main() {
    // Number of intervals - increase for higher precision
    const size_t n = 100000000; // 100 million intervals
    const double dx = 1.0 / n;

    // Vector to store results
    std::vector<double> results(n, 0.0);

    // Compute the result in a serial manner
    for (size_t i = 0; i < n; ++i) {
        double x = (i + 0.5) * dx;
        results[i] = std::sqrt(1.0 - x * x) * dx;
    }

    // Sum up the results
    double pi = 0.0;
    for (const auto& val : results) {
        pi += val;
    }
    pi *= 4.0;

    // Set precision to 10 decimal places and output the result
    std::cout << std::fixed << std::setprecision(10) << "Approximation of Pi: " << pi << std::endl;

    return 0;
}


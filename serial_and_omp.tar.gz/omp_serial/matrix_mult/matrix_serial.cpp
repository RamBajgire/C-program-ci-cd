#include <chrono>
#include <cmath>
#include <iostream>

void display_matrix(float* m, int matSize) {
  if (matSize > 16) {
    return;
  }

  std::cout << "=======" << std::endl;
  for (int i = 0; i < matSize; i++) {
    for (int j = 0; j < matSize; j++) {
      std::cout << m[i * matSize + j] << " ";
    }
    std::cout << std::endl;
  }
  std::cout << "=======" << std::endl;
}

void serial_matrix_multiplication(float* MA, float* MB, float* MC, int matSize) {
  std::cout<<"The order is : "<<matSize<<std::endl;
  for (int i = 0; i < matSize; i++) {
    for (int j = 0; j < matSize; j++) {
      MC[i * matSize + j] = 0.0f;
      for (int k = 0; k < matSize; k++) {
        MC[i * matSize + j] += MA[i * matSize + k] * MB[k * matSize + j];
      }
    }
  }
}

void usage(std::string programName) {
  std::cout << " Incorrect number of parameters " << std::endl;
  std::cout << " Usage: " << std::endl;
  std::cout << programName << " [matrix size]" << std::endl;
  std::cout << "[matrix size] : Size of the matrix to multiply (minimum 32)"
            << std::endl;
}

int main(int argc, char* argv[]) {
  if (argc != 2) {
    usage(argv[0]);
    return 1;
  }

  int matSize = 0;
  try {
    matSize = std::stoi(argv[1]);
  } catch (...) {
    usage(argv[0]);
    return 1;
  }

  if (matSize < 32) {
    usage(argv[0]);
    return 1;
  }

  float* MA = new float[matSize * matSize];
  float* MB = new float[matSize * matSize];
  float* MC = new float[matSize * matSize];

  // Matrix initialization
  for (int i = 0; i < matSize; i++) {
    for (int j = 0; j < matSize; j++) {
      MA[i * matSize + j] = 0.0f;
      if (i == j) {
        MA[i * matSize + j] = 1.0f;
      }
      MB[i * matSize + j] = 2.0f;
      MC[i * matSize + j] = 0.0f;
    }
  }

  std::cout << "Input matrix " << std::endl;
  display_matrix(MA, matSize);
  display_matrix(MB, matSize);
  display_matrix(MC, matSize);

  auto start = std::chrono::steady_clock::now();
  serial_matrix_multiplication(MA, MB, MC, matSize);
  auto end = std::chrono::steady_clock::now();
  auto time =
      std::chrono::duration_cast<std::chrono::milliseconds>(end - start)
          .count();
  std::cout << "Time: " << time << " ms" << std::endl;
  float flops =
      (2.0f * matSize * matSize * matSize / (time / 1000.0f)) * 1.0e-9f;
  std::cout << "GFLOPs: " << flops << std::endl;

  std::cout << "Output matrix" << std::endl;
  display_matrix(MC, matSize);

  // Verification
  bool error = false;
  for (int i = 0; i < matSize; i++) {
    for (int j = 0; j < matSize; j++) {
      if (std::fabs(MC[i * matSize + j] - MB[i * matSize + j]) > 1e-8) {
        std::cout << " Position " << i << ", " << j
                  << " differs: " << MC[i * matSize + j]
                  << " != " << MB[i * matSize + j] << std::endl;
        error = true;
      }
    }
  }

  if (!error) {
    std::cout << "Success" << std::endl;
  } else {
    std::cout << "Error in the computation" << std::endl;
  }

  delete[] MA;
  delete[] MB;
  delete[] MC;

  return error ? 1 : 0;
}

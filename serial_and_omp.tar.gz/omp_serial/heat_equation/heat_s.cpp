#include <iostream>
#include <chrono>
#include <cmath>
#include <vector>

//parascc heat_equation.cpp -O3 -ffast-math -o heat
// Key constants used in this program
#define PI 3.14 // Pi
#define LINE "--------------------" // A line for fancy output

// Function definitions
void initial_value(unsigned int n, double dx, double length, std::vector<std::vector<double>>& u);
void zero(unsigned int n, std::vector<std::vector<double>>& u);
void solve(unsigned int n, double alpha, double dx, double dt, std::vector<std::vector<double>>& u, std::vector<std::vector<double>>& u_tmp);
double solution(double t, double x, double y, double alpha, double length);
double l2norm(unsigned int n, const std::vector<std::vector<double>>& u, int nsteps, double dt, double alpha, double dx, double length);

// Main function
int main(int argc, char *argv[]) {
    // Start the total program runtime timer
    auto start = std::chrono::high_resolution_clock::now();

    // Problem size, forms an nxn grid
    unsigned int n = 6000;

    // Number of timesteps
    int nsteps = 2;

    // Check for the correct number of arguments
    // Print usage and exits if not correct
    if (argc == 3) {
        // Set problem size from first argument
        n = atoi(argv[1]);
        if (n < 0) {
            std::cerr << "Error: n must be positive" << std::endl;
            exit(EXIT_FAILURE);
        }

        // Set number of timesteps from second argument
        nsteps = atoi(argv[2]);
        if (nsteps < 0) {
            std::cerr << "Error: nsteps must be positive" << std::endl;
            exit(EXIT_FAILURE);
        }
    }

    // Set problem definition
    double alpha = 0.1;          // heat equation coefficient
    double length = 1000.0;      // physical size of domain: length x length square
    double dx = length / (n+1);  // physical size of each cell (+1 as don't simulate boundaries as they are given)
    double dt = 0.5 / nsteps;    // time interval (total time of 0.5s)

    // Stability requires that dt/(dx^2) <= 0.5,
    double r = alpha * dt / (dx * dx);

    // Print message detailing runtime configuration
    std::cout
        << std::endl
        << "MMS heat equation" << std::endl << std::endl
        << LINE << std::endl
        << "Problem input" << std::endl << std::endl
        << "Grid size: " << n << " x " << n << std::endl
        << "Cell width: " << dx << std::endl
        << "Grid length: " << length << "x" << length << std::endl
        << std::endl
        << "Alpha: " << alpha << std::endl
        << std::endl
        << "Steps: " <<  nsteps << std::endl
        << "Total time: " << dt*(double)nsteps << std::endl
        << "Time step: " << dt << std::endl
        << LINE << std::endl;

    // Stability check
    std::cout << "Stability" << std::endl << std::endl;
    std::cout << "r value: " << r << std::endl;
    if (r > 0.5)
     //   std::cout << "Warning: unstable" << std::endl;
    std::cout << LINE << std::endl;

    // Allocate two nxn grids
    std::vector<std::vector<double>> u(n, std::vector<double>(n, 0.0));
    std::vector<std::vector<double>> u_tmp(n, std::vector<double>(n, 0.0));

    // Set the initial value of the grid under the MMS scheme
    initial_value(n, dx, length, u);
    zero(n, u_tmp);

    // Run through timesteps under the explicit scheme
    auto tic = std::chrono::high_resolution_clock::now();
    for (int t = 0; t < nsteps; ++t) {
        solve(n, alpha, dx, dt, u, u_tmp);

        // Pointer swap
        auto tmp = std::move(u);
        u = std::move(u_tmp);
        u_tmp = std::move(tmp);   
    }
    auto toc = std::chrono::high_resolution_clock::now();

    // Check the L2-norm of the computed solution
    double norm = l2norm(n, u, nsteps, dt, alpha, dx, length);

    auto stop = std::chrono::high_resolution_clock::now();

    // Print results
    std::cout
        << "Results" << std::endl << std::endl
        << "(L2norm): " << norm << std::endl
        << "Solve time (s): " << std::chrono::duration_cast<std::chrono::duration<double>>(toc-tic).count() << std::endl
        << "Total time (s): " << std::chrono::duration_cast<std::chrono::duration<double>>(stop-start).count() << std::endl
        << "Bandwidth (GB/s): " << 1.0E-9*2.0*n*n*nsteps*sizeof(double)/std::chrono::duration_cast<std::chrono::duration<double>>(toc-tic).count() << std::endl
        << LINE << std::endl;
}

// Sets the mesh to an initial value, determined by the MMS scheme
void initial_value(unsigned int n, double dx, double length, std::vector<std::vector<double>>& u) {
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            double y = dx * (j+1); // Physical y position
            double x = dx * (i+1); // Physical x position
            u[j][i] = sin(PI * x / length) * sin(PI * y / length);
        }
    }
}

// Zero the array u
void zero(unsigned int n, std::vector<std::vector<double>>& u) {
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            u[j][i] = 0.0;
        }
    }
}

// Compute the next timestep, given the current timestep
void solve(unsigned int n, double alpha, double dx, double dt, std::vector<std::vector<double>>& u, std::vector<std::vector<double>>& u_tmp) {
    const double r = alpha * dt / (dx * dx);
    const double r2 = 1.0 - 4.0 * r;

    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            u_tmp[j][i] = r2 * u[j][i] +
                          r * ((i < n-1) ? u[j][i+1] : 0.0) +
                          r * ((i > 0) ? u[j][i-1] : 0.0) +
                          r * ((j < n-1) ? u[j+1][i] : 0.0) +
                          r * ((j > 0) ? u[j-1][i] : 0.0);
        }
    }
}

// True answer given by the manufactured solution
double solution(double t, double x, double y, double alpha, double length) {
    return exp(-2.0 * alpha * PI * PI * t / (length * length)) * sin(PI * x / length) * sin(PI * y / length);
}

// Computes the L2-norm of the computed grid and the MMS known solution
double l2norm(unsigned int n, const std::vector<std::vector<double>>& u, int nsteps, double dt, double alpha, double dx, double length) {
    double time = dt * (double)nsteps;
    double l2norm = 0.0;

    double y = dx;
  for (int j = 0; j < n; ++j) {
    double x = dx;
    for (int i = 0; i < n; ++i) {
      double answer = solution(time, x, y, alpha, length);
      l2norm += (u[j][i] - answer) * (u[j][i] - answer);

      x += dx;
    }
    y += dx;
  }

    return sqrt(l2norm);
}


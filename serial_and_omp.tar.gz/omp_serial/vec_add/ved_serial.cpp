#include <iostream>
#include <vector>

constexpr size_t N = 1000000;

int main() {
    // Allocate memory on the host for vectors A, B, and C
    std::vector<int> A(N, 1);
    std::vector<int> B(N, 2);
    std::vector<int> C(N, 0);

    // Perform the vector addition serially
    for (size_t i = 0; i < N; ++i) {
        C[i] = A[i] + B[i];
    }

    // Print the result
    std::cout << "Result after vector addition:" << std::endl;
   /* for (size_t i = 0; i < N; ++i) {
        std::cout << "C[" << i << "] = " << C[i] << "\n";
    }*/

    return 0;
}

